require(["ecp.service", "ecp.utils.render", 'ecp.model'], function (ecpService, renderUtil, ecpModel) {
  "use strict";

  // 日志对象

  var log = ecpService.Log;

  /**
   * 声明函数对象.
   */
  var PageController = function () {
    //初始化页面
    this.initPage();
  };

  /**
   * 通过原型定义相关方法，比如渲染、赋值等等.
   */
  PageController.prototype = {
    /**
     * 初始化页面.
     */
    initPage: function () {
      //todo
    },
    /**
     * 渲染.
     * 基础控件渲染和统一渲染页面控件
     */
    render: function () {
      //渲染页面控件
      renderUtil.pageRender($.proxy(this.afterRender, this));
    },
    /**
     * 渲染后.
     */
    afterRender: function (map) {
      if (map) {
        for (var i in map) {
          this[i] = map[i];
        }
      }
      //绑定事件
      this.bindEvent();
      this.getPageDataModel();
    },

    /**
     * 绑定事件.
     */
    bindEvent: function () {
      





//@bindEvent
//***controlScript***
//ctrlInfo_ead90d28-bbb6-4fd5-a32e-1d0b7d909012_3.1右侧锚点_f29a5063efb173c3b9347653c78aec10_ctrlInfo
//***controlScript***

//***controlScript***
//ctrlInfo_0714a176-3509-4eb3-92e5-c0334db58b56_3.1分块区域_22dd439c3800d838acdf7b959350413e_ctrlInfo
      //四大面板的折叠收起事件
      jQuery('body').on('click', '.dj_piece_wrapper > .pane-wrapper > .paneTitle > .arrow', function (e) {
        e.preventDefault();
        var el = jQuery(this).closest(".dj_piece_wrapper").children(".piece_content");
        if (jQuery(this).hasClass("expand")) {
          jQuery(this).removeClass("expand");
          jQuery(this).attr("title", "折叠");
          el.slideDown(200);
        } else {
          jQuery(this).addClass("expand");
          jQuery(this).attr("title", "展开");
          el.slideUp(200);
        }
      });
//***controlScript***

//***controlScript***
//ctrlInfo_ba6b8544-e540-48ef-ad45-7368cf004c24_3.1标题_5b0ac6f0b938dc71edbcb6facfc97285_ctrlInfo
//***controlScript***


      





//@bindEvent
    },

    /**
     * 获取页面数据模型.
     */
    getPageDataModel: function () {

      //@getPageDataModel
			//@getPageDataModel 


    },

    /**
     * 绑定数据源.
     */
    bindDataSource: function () {
      var dataModelItems = this.pageDataModel.items || [];
      var dataModelItem = dataModelItems[0];
      this.dataSource = new ecpModel.DataSource();
      this.dataSource.dataModel = dataModelItem;
      this.dataSource.bind($("body"));
    }
    /**
     * 开始执行.
     */
  };var controller = new PageController();
  controller.render();
});