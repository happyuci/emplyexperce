require(["ecp.service", "ecp.utils.render", 'ecp.model'], function (ecpService, renderUtil, ecpModel) {
  "use strict";

  // 日志对象

  var log = ecpService.Log;

  /**
   * 声明函数对象.
   */
  var PageController = function () {
    //初始化页面
    this.initPage();
  };

  /**
   * 通过原型定义相关方法，比如渲染、赋值等等.
   */
  PageController.prototype = {
    /**
     * 初始化页面.
     */
    initPage: function () {
      //todo
      var winH = $(window).height();

      $(".gridRect").css('height', winH - 250);
    },
    /**
     * 渲染.
     * 基础控件渲染和统一渲染页面控件
     */
    render: function () {
      //渲染页面控件
      renderUtil.pageRender($.proxy(this.afterRender, this));
    },
    /**
     * 渲染后.
     */
    afterRender: function (map, base) {
      //通过指针调用控件ID即可获取控件对象
      base(this);
      //绑定事件
      this.bindEvent();
      this.loadData();
    },

    /**
     * 绑定事件.
     */
    bindEvent: function () {
      

//@bindEvent
      //***controlScript***
      //ctrlInfo_f35f19db-786b-4aeb-91d8-301d3bf4cbe6_设置查询_0ae0d3dd31dd52ece59b4503fe7a03e1_ctrlInfo
      //***controlScript***

      //***controlScript***
      //ctrlInfo_38948ded-6131-4dad-ab5d-d0a5f8f96d7c_方案查询_ea6b13609ba5c6a48c75f7d2d4fac611_ctrlInfo
      //***controlScript***

      //***controlScript***
      //ctrlInfo_a123b654-7fcb-4207-9a7d-1a6809fcdd94_更多查询_c49a4cb8001bf34aa952a5ff8cf3bd0e_ctrlInfo
      var queryInner = $(".query_inner");
      $(".query_inner").click(function () {
        var queryInnerZone = $(".query_inner_zone");
        var queryInnerSpan = $(this).find("span");
        if (queryInner.hasClass("shrink")) {
          queryInnerZone.hide();
          queryInner.removeClass("shrink").addClass("expand");
          queryInnerSpan.html("更多");
        } else if (queryInner.hasClass("expand")) {
          queryInnerZone.show();
          queryInner.removeClass("expand").addClass("shrink");
          queryInnerSpan.html("收起");
        } else {
          return;
        }
      });
      //***controlScript***

      //***controlScript***
      //ctrlInfo_a1d05057-b263-4076-8bc3-c1763f128dc0_模态窗查询区_0b029d73331e2cfe8aca357b98a6776c_ctrlInfo
      //***controlScript***

      //***controlScript***
      //ctrlInfo_dc5356f7-a3dc-445e-8feb-acadc127bd99_状态查询_7cee811837975b03d5d21a11003eb8c0_ctrlInfo
      //***controlScript***

      //***controlScript***
      //ctrlInfo_38948ded-6131-4dad-ab5d-d0a5f8f96d7c_方案查询_b749548c284181e2261777d7150a5786_ctrlInfo
      //***controlScript***
      //***controlScript***
      //ctrlInfo_1267d461-f3b2-4172-8f4b-d29836e5acb8_普通查询_c8fc9252d6837c24903fb7a3a9ef5a0f_ctrlInfo

      //***controlScript***
      //***controlScript***
      //ctrlInfo_114c9364-15f6-4439-8bf5-b884fe695812_页面工具栏_9624cd79ead556eeb816927cb47d6c19_ctrlInfo

      //***controlScript***
      //ctrlInfo_ecptable_root_com_9bd3e50222c386f7787d89e0e4f95cd0__tableEvent_ctrlInfo_ecptable
      var grid_root = this["root"];
      var me = this;
      if (grid_root) {
        try {

          this.handleGridTotalAndPager(grid_root, false, true, '', '');
        } catch (e) {
          console.log(e);
        }
      }
      //ctrlInfo_ecptable_root_com_9bd3e50222c386f7787d89e0e4f95cd0__tableEvent_ctrlInfo_ecptable
      

//@bindEvent
    },

    /**
     * 获取页面数据模型.
     */
    loadData: function () {

      //@loadData
			//@loadData 


    },

    /**
     * 绑定数据源.
     */
    bindDataSource: function () {
      this.dataSource = new ecpModel.DataSource();
      this.dataSource.dataModel = this.dataModel;
      this.dataSource.bind($("body"));
    },
    handleGridTotalAndPager: function (grid, pager, total, firstTableId, ngModel) {
      var gridData = grid.option.data || [];

      if (total) {
        var colModels = grid.option.colModels || [];
        var totalFields = {};
      }

      if (pager) {
        var pageSize = grid.getPageSize();
        grid.setTotalRecord(gridData.length, false);
        grid.value(gridData.slice(0, pageSize));
        grid.bind("onPageChanged", function (pageCount, pageSize, pageIndex) {
          var data = grid.option.data.slice(pageSize * (pageIndex - 1), pageSize + pageSize * (pageIndex - 1));
          grid.value(data);

          if (total) {}
        });
      }

      if (total) {
        colModels.forEach(function (cm) {
          if (cm.sum) {
            totalFields[cm.name] = 0;
          }
        });
        gridData.forEach(function (obj) {
          for (var p in totalFields) {
            if (!isNaN(obj[p]) && (!grid.option.treeGrid || obj.pid == "#" || !obj.pid)) {
              totalFields[p] += Number(obj[p]);
            }
          }
        });
        this.afterLoadDataTasks = this.afterLoadDataTasks || [];
        this.afterLoadDataTasks.push(function () {
          if (pager) {
            grid.value(gridData.slice(0, pageSize));
          }
        });
      }

      if (pager) {
        if (firstTableId && ngModel) {
          this.setSecondGridValue(grid, pager, firstTableId, ngModel);
        } else {
          this.afterLoadDataTasks = this.afterLoadDataTasks || [];
          this.afterLoadDataTasks.push(function () {
            grid.value(gridData.slice(0, pageSize));
          });
        }
      }
    },
    setSecondGridValue: function (grid, pager, firstTableId, ngModel) {
      var me = this;

      if (me[firstTableId]) {
        me.afterLoadDataTasks = me.afterLoadDataTasks || [];
        me.afterLoadDataTasks.push(function () {
          var firstGridData = me[firstTableId].value();
          var gridData = firstGridData[0] && firstGridData[0][ngModel] || [];

          if (pager) {
            gridData = gridData.slice(0, +grid.getPageSize());
          }

          grid.value(gridData);
        });
      }
    }
  };
  /**
   * 开始执行.
   */
  var controller = new PageController();
  controller.render();
});